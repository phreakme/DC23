#!/usr/bin/php
<?php
set_time_limit(30);
require('phpagi.php');
$agi = new AGI();
$agi->answer();

$agi->text2wav("Goodbye");

$agi->hangup();
?>
