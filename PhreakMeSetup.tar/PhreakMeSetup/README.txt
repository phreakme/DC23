Setup TurnKeyLinux Core
http://www.turnkeylinux.org/core

- setup network (if you wish)

- use aptinstall.sh script to install packages (amd64 vbox)
	chmod 700 aptinstall.sh
	./aptinstall.sh

ITU-t 1 (for US) others need tweaking

Copy screenrc into /root/.screenrc (if desired)
	cp screenrc /root/.screenrc
	
- Delete Base Asterisk Configs
	cp /etc/asterisk/ -r /etc/asterisk.bak
	rm /etc/asterisk/* -rf

Replace all <VAR's> with your variables
 In case of double << or >> just replace the innermost <VAR> (used in callerid)

- Configure your PBX
	- sip.conf
	- extensions.conf

Install PhreakMe from script
copy configs/* to /etc/asterisk/
copy agi-bin/* to /usr/share/asterisk/agi-bin/
copy /opt/phreakme

Symlink Outgoing
	ln -s /var/spool/asterisk/outgoing /opt/phreakme/skel/outgoing 
	
Change Ownership
chown -R asterisk:asterisk /opt/phreakme
chown -R asterisk:asterisk /usr/share/asterisk/agi-bin

TEST (this is the hard part)
permissions may need to be changed on opt/phreakme and agi-bin scripts